package com.zybooks.weightapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.weightapplication.MainScreen;
import com.zybooks.weightapplication.R;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Initialize DB
        UserDatabase db = UserDatabase.getInstance(this);
        // Get User List in Log
        List<String> users = db.getUsers();
        Log.d("DB", "User List: " + users);


        // UI Initializations
        Button loginBTN = findViewById(R.id.loginButton);
        Button accountBTN = findViewById(R.id.createButton);
        EditText usernameText = findViewById(R.id.usernameText);
        EditText passwordText = findViewById(R.id.passwordText);

        // Login Button
        loginBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Checks to see if user already exists in database, if yes, checks to see if password matches
                List<String> users = db.getUsers();
                if ((!usernameText.getText().toString().isEmpty()) && (users.contains(usernameText.getText().toString()))) {
                    if ((!passwordText.getText().toString().isEmpty()) && (passwordText.getText().toString().equals(db.getPassword(usernameText.getText().toString())))) {
                        User user = new User(usernameText.getText().toString());
                        Intent intent = new Intent(MainActivity.this, MainScreen.class);
                        startActivity(intent);
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Invalid Username/Password", Toast.LENGTH_LONG).show();
                }
            }
        });
        // Create Account Button
        accountBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // GOES TO PERMISSION SCREEN FIRST SINCE NEW USER
                List<String> users = db.getUsers();
                if ((!usernameText.getText().toString().isEmpty()) && (!users.contains(usernameText.getText().toString()))) {
                    if ((!passwordText.getText().toString().isEmpty())) {
                        // Create New USER IN DB
                        db.createNewUser(usernameText.getText().toString(), passwordText.getText().toString(), null, "-,-,-,-,-,-,-", null, null);
                        User user = new User(usernameText.getText().toString());
                        Log.d("Db", "User: " + User.mUsername);
                        Intent intent = new Intent(MainActivity.this, PermissionScreen.class);
                        startActivity(intent);
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Invalid Values or Account with Username already exists", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}