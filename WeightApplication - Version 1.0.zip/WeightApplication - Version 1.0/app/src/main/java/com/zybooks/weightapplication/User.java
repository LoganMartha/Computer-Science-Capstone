package com.zybooks.weightapplication;

public class User {
    public static String mUsername;


    public User() {}

    public User(String name) {
        mUsername = name;
    }
    //SETTERS
    public void setUsername(String name) {
        mUsername = name;
    }
    //GETTERS
    public String getUsername() {
        return mUsername;
    }

}
