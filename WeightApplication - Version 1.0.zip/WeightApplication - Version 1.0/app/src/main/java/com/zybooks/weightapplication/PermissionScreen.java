package com.zybooks.weightapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PermissionScreen extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_permission_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // UI Attributes
        EditText phoneNumber = findViewById(R.id.phoneNumber);
        Button yesButton = findViewById(R.id.yesButton);
        Button noButton = findViewById(R.id.noButton);
        UserDatabase db = UserDatabase.getInstance(this);


        //Text Watcher for only yesButton to enable if number entered
        phoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not needed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // If statement ensures for valid number length with '-'
                if (phoneNumber.getText() != null && phoneNumber.getText().length() >= 10 && phoneNumber.getText().length() < 13 && !phoneNumber.getText().toString().isEmpty()) {
                    yesButton.setEnabled(true);
                } else {
                    yesButton.setEnabled(false);
                }
            }


            @Override
            public void afterTextChanged(Editable s) {
                // Not needed
            }
        });

        // Yes Button Click
        yesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO allowPermission() function
                db.setPhoneNumber(User.mUsername, phoneNumber.getText().toString());
                db.setPermissions(User.mUsername, "1");;
                Intent intent = new Intent(PermissionScreen.this, MainScreen.class);
                startActivity(intent);
            }
        });

        // No Button Click
        noButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.setPermissions(User.mUsername, "0");
                Intent intent = new Intent(PermissionScreen.this, MainScreen.class);
                startActivity(intent);
            }
        });

    }
}