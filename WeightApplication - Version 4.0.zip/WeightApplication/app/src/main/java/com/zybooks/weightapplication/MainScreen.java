package com.zybooks.weightapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.WeakHashMap;
import android.telephony.SmsManager;

import org.w3c.dom.Text;


public class MainScreen extends AppCompatActivity {
    List<TextView> weightViews = new ArrayList<TextView>();

    // Initialize DBs
    UserDatabase db = UserDatabase.getInstance(this);
    WeightDatabase wdb = WeightDatabase.getInstance(this);

    private boolean goalNotificationShown = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainScreen), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Weight Display Text Views:
        TextView weightOne = findViewById(R.id.weightOne);
        TextView weightTwo = findViewById(R.id.weightTwo);
        TextView weightThree = findViewById(R.id.weightThree);
        TextView weightFour = findViewById(R.id.weightFour);
        TextView weightFive = findViewById(R.id.weightFive);
        TextView weightSix = findViewById(R.id.weightSix);
        TextView weightSeven = findViewById(R.id.weightSeven);

        // Add TextViews to the list
        weightViews.add(weightOne);
        weightViews.add(weightTwo);
        weightViews.add(weightThree);
        weightViews.add(weightFour);
        weightViews.add(weightFive);
        weightViews.add(weightSix);
        weightViews.add(weightSeven);

        // UI Attribute
        Button logoutButton = findViewById(R.id.logout);
        Button setGoalButton = findViewById(R.id.setGoalButton);
        Button addDataButton = findViewById(R.id.addDataButton);
        EditText setGoalText = findViewById(R.id.setGoalText);
        EditText addDataText = findViewById(R.id.addDataText);
        TextView goalText = findViewById(R.id.goalText);
        TextView userText = findViewById(R.id.userText);
        TextView progressText = findViewById(R.id.progressTextView);

        //Clear Button
        Button clearRowOne = findViewById(R.id.clearRowOne);
        Button clearRowTwo = findViewById(R.id.clearRowTwo);
        Button clearRowThree = findViewById(R.id.clearRowThree);
        Button clearRowFour = findViewById(R.id.clearRowFour);
        Button clearRowFive = findViewById(R.id.clearRowFive);
        Button clearRowSix = findViewById(R.id.clearRowSix);
        Button clearRowSeven = findViewById(R.id.clearRowSeven);

        //Display Starter Data
        goalText.setText("Goal: " + db.getGoal(User.mUsername));
        userText.setText("User: " + User.mUsername);
        progressText.setText("Progress: " + progressCheck() + " from goal!");
        displayWeight(wdb.getWeights(User.mUsername));

        // Goal Shown Boolean, to only show one
        boolean goalNotificationShown = false;

        // Text Listener for setGoal
        setGoalText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not needed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (setGoalText.getText() != null && !setGoalText.getText().toString().isEmpty()) {
                    setGoalButton.setEnabled(true);
                } else {
                    setGoalButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Not needed
            }
        });

        // Text Listener for addData
        addDataText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (addDataText.getText() != null && !addDataText.getText().toString().isEmpty()) {
                    addDataButton.setEnabled(true);
                } else {
                    addDataButton.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        // Logout Button Click

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Message = "You have successfully Logged Out";
                // Returns new login Screen
                Intent intent = new Intent(MainScreen.this, MainActivity.class);
                startActivity(intent);
                // Outputs Message stating successful logout
                Toast.makeText(MainScreen.this, Message, Toast.LENGTH_LONG).show();
            }
        });

        //SetGoal Button Click
        setGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.setGoal(User.mUsername, setGoalText.getText().toString());
                goalText.setText("Goal: "+ db.getGoal(User.mUsername));
            }
        });

        //AddData Button Click
        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check for full data (7)
                List<String> weightsList = wdb.getWeights(User.mUsername);
                if (!isCharInList(weightsList, "-")) {
                    Toast.makeText(MainScreen.this, "Data Full. Remove one before adding", Toast.LENGTH_SHORT).show();
                }
                else {
                    addWeight(addDataText.getText().toString());
                    displayWeight(wdb.getWeights(User.mUsername));
                }
                // Checks goal status and updates progress after every new weight is added
                goalStatus();
                progressText.setText("Progress: " + progressCheck() + " from goal!");
            }
        });
        //Clear ButtonClick ONE
        clearRowOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!weightOne.getText().toString().isEmpty() && !weightOne.getText().toString().equals("-")) {
                    deleteWeight(weightOne.getText().toString(), 0);
                    progressText.setText("Progress: " + progressCheck() + " from goal!");
                }
            }
        });
        //Clear ButtonClick Two
        clearRowTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!weightTwo.getText().toString().isEmpty() && !weightTwo.getText().toString().equals("-")) {
                    deleteWeight(weightTwo.getText().toString(), 1);
                    progressText.setText("Progress: " + progressCheck() + " from goal!");
                }
            }
        });
        //Clear ButtonClick Three
        clearRowThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!weightThree.getText().toString().isEmpty() && !weightThree.getText().toString().equals("-")) {
                    deleteWeight(weightThree.getText().toString(), 2);
                    progressText.setText("Progress: " + progressCheck() + " from goal!");
                }
            }
        });
        //Clear ButtonClick Four
        clearRowFour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!weightFour.getText().toString().isEmpty() && !weightFour.getText().toString().equals("-")) {
                    deleteWeight(weightFour.getText().toString(), 3);
                    progressText.setText("Progress: " + progressCheck() + " from goal!");
                }
            }
        });
        //Clear ButtonClick Five
        clearRowFive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!weightFive.getText().toString().isEmpty() && !weightFive.getText().toString().equals("-")) {
                    deleteWeight(weightFive.getText().toString(), 4);
                    progressText.setText("Progress: " + progressCheck() + " from goal!");
                }
            }
        });
        //Clear ButtonClick Six
        clearRowSix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!weightSix.getText().toString().isEmpty() && !weightSix.getText().toString().equals("-")) {
                    deleteWeight(weightSix.getText().toString(), 5);
                    progressText.setText("Progress: " + progressCheck() + " from goal!");
                }
            }
        });
        //Clear ButtonClick Seven
        clearRowSeven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!clearRowSeven.getText().toString().isEmpty() && !weightSeven.getText().toString().equals("-")) {
                    deleteWeight(weightSeven.getText().toString(), 6);
                    progressText.setText("Progress: " + progressCheck() + " from goal!");
                }
            }
        });

    }
    // Display weights in grid layout
    public void displayWeight(List<String> weight) {
        //Clear Table First
        for(TextView view : weightViews){
            view.setText("-");
        }
        // Populate with New Weights
        for (int i = 0; i < weight.size(); i++) {
            weightViews.get(i).setText(weight.get(i));
        }
    }


    // Add weight to current weight string
    public void addWeight(String weight) {
        List<String> weights = wdb.getWeights(User.mUsername);
        for (int i = 0; i < weights.size(); i++) {
            if (weights.get(i).equals("-")) {
                weights.set(i, weight);
                break;// Update the actual element
            }
        }
        wdb.setWeights(User.mUsername, weights);  // Save updated weights to database
        Log.d("DB", weights.toString());  // Optional: Log the updated weights
    }

    // Delete weight from current weight string
    public void deleteWeight(String weight, int i) {
        List<String> weights = wdb.getWeights(User.mUsername);
        weights.set(i, "-");

        wdb.setWeights(User.mUsername, weights);// Save updated weights to database
        displayWeight(wdb.getWeights(User.mUsername));
        Log.d("DB", wdb.getWeights(User.mUsername).toString());  // Optional: Log the updated weights
    }

    // Method to check if character exists in the list
    public static boolean isCharInList(List<String> list, String ch) {
        for (int i = 0; i < list.size(); ++i) {
            if(list.get(i).equals(ch)) {
                return true;
            }
        }
        return false;
    }

    //Check if goal met
    public void goalStatus() {
        List<String> weightList = wdb.getWeights(User.mUsername);
        Log.d("Goal: ", db.getGoal(User.mUsername));
        for (String w : weightList) {
            if(w.equals(db.getGoal(User.mUsername))) {
                goalNotification();
            }
        }
    }

    //Progress Check Function
    public String progressCheck() {
        // Get weights and move to list to iterate through
        String progressNum = "-";

        List<String> weightList = wdb.getWeights(User.mUsername);

        for (int i = weightList.size() - 1; i >= 0; i--) {
            if (weightList.get(i).equals("-")) { // Looking for last instance of weight
                continue;
            } else { // When found, need to get rid of "lbs" from string, then subtract goal from current to get pounds from goal
                // Get rid of "lbs" from string to turn to int
                String goalString = db.getGoal(User.mUsername).substring(0, db.getGoal(User.mUsername).length() - 3); // takes "lbs" off from goal string
                int goalNum = Integer.parseInt(goalString); // Changes goal string to int

                String currentString = weightList.get(i).substring(0, weightList.get(i).length() - 3); // takes "lbs" from current weight string
                int currentNum = Integer.parseInt(currentString); // Changes current weight string to int

                progressNum = Integer.toString(goalNum - currentNum); // Gets progress int
                Log.d("Progress", progressNum + "lbs"); // Logs in console for testing
                break; // Exits because we got most recent weight
            }
        }

        return progressNum + "lbs"; // returns proper string format ex: "20lbs"
    }

    //Notification System
    //Sends SMS if allowed, TOAST message in app if not
    public void goalNotification() {
        if (goalNotificationShown) return;

        String Message = "Congratulations! You have reached your weight goal!";
        if(db.getPermission(User.mUsername).equals("1")) {
            // Send SMS
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(db.getNumber(User.mUsername), null, Message, null, null);
                // Log Message if SMS sent successfully
                Log.d("SMS", "Message sent successfully!");
            } catch (Exception e) {
                Log.e("PermissionScreen", "SMS sending failed", e);
                Toast.makeText(MainScreen.this, "Failed to send message.", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(MainScreen.this, Message, Toast.LENGTH_LONG).show();
        }
        goalNotificationShown = true;
    }
}

