package com.zybooks.weightapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 102;
    private static final String DATABASE_NAME = "userDB";
    private static UserDatabase instance;

    public UserDatabase(Context context) {super(context, DATABASE_NAME, null, VERSION); }
    public static UserDatabase getInstance(Context context) {
        if (instance == null) {
            instance = new UserDatabase(context);
        }
        return instance;
    }


    // Data Table Elements
    public static final class UserTable{
        public static final String TABLE = "users";
        public static final String COL_USERNAME = "username";
        public static final String COL_PASSWORD = "password";
        public static final String COL_NUMBER = "number";
        public static final String COL_PERMISSIONS = "permissions"; // 0 = false 1 = true
        public static final String COL_GOAL = "goal";


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + UserTable.TABLE + " (" +
                UserTable.COL_USERNAME + " TEXT PRIMARY KEY, " +
                UserTable.COL_PASSWORD + " TEXT NOT NULL, " +
                UserTable.COL_NUMBER + " TEXT DEFAULT '-', " +
                UserTable.COL_GOAL + " TEXT DEFAULT '-', " +
                UserTable.COL_PERMISSIONS + " INTEGER DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }


    // Method to Create User
    public void createNewUser(String username, String password, String permission, String number, String goal) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username);
        values.put(UserTable.COL_PASSWORD, password);
        values.put(UserTable.COL_PERMISSIONS, permission);
        values.put(UserTable.COL_GOAL, goal);
        values.put(UserTable.COL_NUMBER, number);


        long result = db.insert(UserTable.TABLE, null, values);

    }
    // Method to Clear All Data from the Users Table
    public void clearUserDatabase() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + UserTable.TABLE);
        db.close(); // Optional but recommended to release resources
    }

    //Get All Users
    public List<String> getUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        List<String> userList = new ArrayList<>();

        //Query To Select All usernames
        String query = "SELECT " + UserTable.COL_USERNAME + " FROM " + UserTable.TABLE;
        Cursor cursor = db.rawQuery(query,null);

        //Iterate Through Results
        if(cursor.moveToFirst()) {
            do{
                int columnIndex = cursor.getColumnIndex(UserTable.COL_USERNAME);
                String username = cursor.getString(columnIndex);
                userList.add(username);
            } while(cursor.moveToNext());
        }

        cursor.close();
        return userList;
    }


// GETTERS

    // GET PASSWORD
    public String getPassword(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String password;
        // Query to Select Password from data with user name
        String query = "SELECT " + UserTable.COL_PASSWORD + " FROM " + UserTable.TABLE +
                        " WHERE " + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        // Iterate through results
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(UserTable.COL_PASSWORD);
            password = cursor.getString(columnIndex);
        } else {
            password = "";
        }
        cursor.close();
        return password; // If no matching password, empty string returned
    }
    // GET NUMBER
    public String getNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String number;
        // Query to Select Password from data with user name
        String query = "SELECT " + UserTable.COL_NUMBER + " FROM " + UserTable.TABLE +
                " WHERE " + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        // Iterate through results
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(UserTable.COL_NUMBER);
            number = cursor.getString(columnIndex);
        } else {
            number = " ";
        }
        cursor.close();
        return number; // If no matching password, empty string returned
    }

    //Get Goal
    public String getGoal(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String goal = "None";
        // Query to Select Password from data with user name
        String query = "SELECT " + UserTable.COL_GOAL + " FROM " + UserTable.TABLE +
                " WHERE " + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        // Iterate through results
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(UserTable.COL_GOAL);
            goal = cursor.getString(columnIndex);
            if (goal == null || goal.isEmpty()) {
                goal = "None";
            }
        }

        cursor.close();
        return goal;
    }

    //Get Permission
    public String getPermission(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String permission;
        // Query to Select Password from data with user name
        String query = "SELECT " + UserTable.COL_PERMISSIONS + " FROM " + UserTable.TABLE +
                " WHERE " + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        // Iterate through results
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(UserTable.COL_PERMISSIONS);
            permission = cursor.getString(columnIndex);
        } else {
            permission = "";
        }
        cursor.close();
        return permission;
    }
//SETTERS
    
    // SET NUMBER
    public void setPhoneNumber(String username, String number) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_NUMBER, number);

        String selection = UserTable.COL_USERNAME + " = ?";
        String[] selectionArgs = { username };

        db.update(UserTable.TABLE, values, selection, selectionArgs);
        db.close();
    }

    // SET Permissions
    public void setPermissions(String username, String permissions) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_PERMISSIONS, permissions);

        String selection = UserTable.COL_USERNAME + " = ?";
        String[] selectionArgs = { username };

        db.update(UserTable.TABLE, values, selection, selectionArgs);
        db.close();
    }


    // SET Goal
    public void setGoal(String username, String goal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_GOAL, goal);

        String selection = UserTable.COL_USERNAME + " = ?";
        String[] selectionArgs = { username };

        db.update(UserTable.TABLE, values, selection, selectionArgs);
        db.close();
    }


}
