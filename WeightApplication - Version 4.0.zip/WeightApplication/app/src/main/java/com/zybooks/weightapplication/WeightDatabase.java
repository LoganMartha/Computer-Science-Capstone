package com.zybooks.weightapplication;

import android.app.usage.UsageEvents;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WeightDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 100;
    private static final String DATABASE_NAME = "weightDB";
    private static WeightDatabase instance;

    public WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static WeightDatabase getInstance(Context context) {
        if (instance == null) {
            instance = new WeightDatabase(context);
        }
        return instance;
    }


    // Data Table Elements
    //  Default Values set to "-" for display purposes
    public static final class WeightTable {
        public static final String TABLE = "weights";
        public static final String COL_USERNAME = "username";
        public static final String COL_WEIGHT_ONE = "weightOne";
        public static final String COL_WEIGHT_TWO = "weightTwo";
        public static final String COL_WEIGHT_THREE = "weightThree";
        public static final String COL_WEIGHT_FOUR = "weightFour";
        public static final String COL_WEIGHT_FIVE = "weightFive";
        public static final String COL_WEIGHT_SIX = "weightSix";
        public static final String COL_WEIGHT_SEVEN = "weightSeven";


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create Table " + WeightTable.TABLE + "( " +
                WeightTable.COL_USERNAME + " TEXT PRIMARY KEY, " +
                WeightTable.COL_WEIGHT_ONE + "TEXT DEFAULT '-', " +
                WeightTable.COL_WEIGHT_TWO + " TEXT DEFAULT '-', " +
                WeightTable.COL_WEIGHT_THREE +  " TEXT DEFAULT '-', " +
                WeightTable.COL_WEIGHT_FOUR + " TEXT DEFAULT '-', " +
                WeightTable.COL_WEIGHT_FIVE + " TEXT DEFAULT '-', " +
                WeightTable.COL_WEIGHT_SIX + " TEXT DEFAULT '-', " +
                WeightTable.COL_WEIGHT_SEVEN + " TEXT DEFAULT '-' )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }


    // Method to Create User
    public void createNewUserWeights(String username, String weightOne, String weightTwo, String weightThree, String weightFour, String weightFive, String WeightSix, String weightSeven) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_USERNAME, username);
        values.put(WeightTable.COL_WEIGHT_ONE, weightOne);
        values.put(WeightTable.COL_WEIGHT_TWO, weightTwo);
        values.put(WeightTable.COL_WEIGHT_THREE, weightThree);
        values.put(WeightTable.COL_WEIGHT_FOUR, weightFour);
        values.put(WeightTable.COL_WEIGHT_FIVE, weightFive);
        values.put(WeightTable.COL_WEIGHT_SIX, WeightSix);
        values.put(WeightTable.COL_WEIGHT_SEVEN, weightSeven);


        long result = db.insert(WeightTable.TABLE, null, values);
    }

    // Method to Clear All Data from the Weight Table
    public void clearWeightDatabase() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + WeightTable.TABLE);
        db.close(); // Optional but recommended to release resources
    }

    // Get Weights
    public List<String> getWeights(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<String> weightList = new ArrayList<>();

        //Query To Select All Weights for a Username
        String query = "SELECT " +
                WeightTable.COL_WEIGHT_ONE + ", " +
                WeightTable.COL_WEIGHT_TWO + ", " +
                WeightTable.COL_WEIGHT_THREE + ", " +
                WeightTable.COL_WEIGHT_FOUR + ", " +
                WeightTable.COL_WEIGHT_FIVE + ", " +
                WeightTable.COL_WEIGHT_SIX + ", " +
                WeightTable.COL_WEIGHT_SEVEN +
                " FROM " + WeightTable.TABLE + " WHERE " + WeightTable.COL_USERNAME  + " =?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        //Iterate Through Results
        if (cursor.moveToFirst()) {
            // Loop through all 7 weight columns
            for (int i = 0; i < cursor.getColumnCount(); i++) {
                weightList.add(cursor.getString(i));  // add weight value
            }
        }

        cursor.close();
        return weightList;
    }
    // Set Weights
    public void setWeights(String username, List<String> weights) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(WeightTable.COL_WEIGHT_ONE, weights.get(0));
        values.put(WeightTable.COL_WEIGHT_TWO, weights.get(1));
        values.put(WeightTable.COL_WEIGHT_THREE, weights.get(2));
        values.put(WeightTable.COL_WEIGHT_FOUR, weights.get(3));
        values.put(WeightTable.COL_WEIGHT_FIVE, weights.get(4));
        values.put(WeightTable.COL_WEIGHT_SIX, weights.get(5));
        values.put(WeightTable.COL_WEIGHT_SEVEN, weights.get(6));

        db.update(
                WeightTable.TABLE,
                values,
                WeightTable.COL_USERNAME + " = ?",
                new String[]{username}
        );

        db.close();
    }

}
